from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from . import services, schemas, db
from fastapi.responses import FileResponse

router = APIRouter()

@router.get("/items")
def read_items(db: Session = Depends(db.get_db)):
    return services.get_items(db)

@router.post("/items")
def create_item(item: schemas.ItemCreate, db: Session = Depends(db.get_db)):
    return services.create_item(db, item)

@router.put("/items/{item_id}")
def update_item(item_id: int, item: schemas.ItemUpdate, db: Session = Depends(db.get_db)):
    return services.update_item(db, item_id, item)

@router.delete("/items/{item_id}")
def delete_item(item_id: int, db: Session = Depends(db.get_db)):
    return services.delete_item(db, item_id)

@router.get("/items/export")
def export_items(db: Session = Depends(db.get_db)):
    file_path = services.export_to_excel(db)
    return FileResponse(file_path, media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', filename=file_path)
