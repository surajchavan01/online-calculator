from sqlalchemy.orm import Session
from . import schemas
from sqlalchemy import text
import openpyxl
from fastapi.responses import FileResponse

# Raw query examples (convert your PHP queries here)
def get_items(db: Session):
    query = text("SELECT * FROM items")
    result = db.execute(query).fetchall()
    return [dict(r) for r in result]

def create_item(db: Session, item: schemas.ItemCreate):
    query = text("INSERT INTO items (name, description, price) VALUES (:name, :description, :price) RETURNING id")
    result = db.execute(query, {"name": item.name, "description": item.description, "price": item.price})
    db.commit()
    return {"id": result.fetchone()[0]}

def update_item(db: Session, item_id: int, item: schemas.ItemUpdate):
    query = text("UPDATE items SET name=:name, description=:description, price=:price WHERE id=:id")
    db.execute(query, {"id": item_id, "name": item.name, "description": item.description, "price": item.price})
    db.commit()
    return {"status": "updated"}

def delete_item(db: Session, item_id: int):
    query = text("DELETE FROM items WHERE id=:id")
    db.execute(query, {"id": item_id})
    db.commit()
    return {"status": "deleted"}

# Excel export
def export_to_excel(db: Session, file_name: str = "report.xlsx"):
    items = get_items(db)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["ID", "Name", "Description", "Price"])
    for item in items:
        ws.append([item["id"], item["name"], item["description"], item["price"]])
    wb.save(file_name)
    return file_name
